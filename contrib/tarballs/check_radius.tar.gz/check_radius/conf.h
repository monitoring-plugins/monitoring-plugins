/* Default Database File Names */

#define RADIUS_DIR		"/etc/raddb"
#define RADACCT_DIR		"/var/log/radacct"
#define RADLOG_DIR		"/var/log"

#define RADIUS_DICTIONARY	"dictionary"
#define RADIUS_CLIENTS		"clients"
#define RADIUS_NASLIST		"naslist"
#define RADIUS_USERS		"users"
#define RADIUS_HOLD		"holdusers"
#define RADIUS_LOG		"radius.log"
#define RADIUS_HINTS		"hints"
#define RADIUS_HUNTGROUPS	"huntgroups"
#define RADIUS_REALMS		"realms"

#define RADUTMP			"/var/log/radutmp"
#define RADWTMP			"/var/log/radwtmp"

#define RADIUS_PID		"/var/run/radiusd.pid"

#define CHECKRAD1		"/usr/sbin/checkrad"
#define CHECKRAD2		"/usr/local/sbin/checkrad"

/* Hack for funky ascend ports on MAX 4048 (and probably others)
   The "NAS-Port-Id" value is "xyyzz" where "x" = 1 for digital, 2 for analog;
   "yy" = line number (1 for first PRI/T1/E1, 2 for second, so on);
   "zz" = channel number (on the PRI or Channelized T1/E1).
    This should work with normal terminal servers, unless you have a TS with
        more than 9999 ports ;^).
    The "ASCEND_CHANNELS_PER_LINE" is the number of channels for each line into
        the unit.  For my US/PRI that's 23.  A US/T1 would be 24, and a
        European E1 would be 30 (I think ... never had one ;^).
    This will NOT change the "NAS-Port-Id" reported in the detail log.  This
        is simply to fix the dynamic IP assignments a la Cistron.
    WARNING: This hack works for me, but I only have one PRI!!!  I've not
        tested it on 2 or more (or with models other than the Max 4048)
    Use at your own risk!
  -- dgreer@austintx.com
*/
#define ASCEND_PORT_HACK
#define ASCEND_CHANNELS_PER_LINE        23

/*
 *	Hack for USR gear - uses a different Vendor-Specific attribute
 *	packet layout, argh.
 */
#define ATTRIB_NMC

/*
 *	Hack to enable use of 1.5.4.3 dictionaries.
 */
#define COMPAT_1543

