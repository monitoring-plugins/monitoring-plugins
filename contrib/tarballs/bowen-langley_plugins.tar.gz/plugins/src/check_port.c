/*                                                                          
        Source: check_port.c
        Author: Adam G. Bowen (agbowen@bealenet.com)
        $Revision: 1.1 $
        $Date: 1999/05/17 14:25:31 $
 
 * Program: PORT socket plugin for NetSaint
 * License: GPL
 * Copyright (c) 1999 Adam G. Bowen (agbowen@bealenet.com)
 *
 * Description:
 *
 * This plugin will establish a socket on the port number passed on the command
 * line to the host specified by ipaddress.   If any error occures while
 * creating the socket, or closing the socket, this error will result in an
 * alert.  The incorrect responce or responce time above the threshold vaules
 * will also cause an alert. 
 *
 * Other errors result in a STATE_UNKNOWN return.
 *
 * Command line:
 *
 * check_port ipaddress sys_type port_number protocol
 * check_port ipaddress sys_type port_number protocol <warn_ms> <crit_ms>
 *
 * Required input:
 *
 * ipaddress = The ipaddress of the remote system to run the check on.
 * sys_type = The remote system type.
 * port_number = The port to connect to on the remote system.
 * protocol = The protocol to use for the socket connection.
 *
 * Optional input:
 *
 * <warn_ms> = Number of miliseconds necessary to result in a WARNING state.
 * <crit_ms> = Number of miliseconds necessary to result in a CRITICAL state.
 *
 * Notes:
 *
 * If <warn_ms> and <crit_ms> are not passed on the command line, they will be 
 * set to the default values in the check_fs config file.
 *
 * sys_type is used to determine which config file to use to generate the
 * remote command.
 *
 * The configuration file /usr/local/netsaint/config/check_port/<sys_type>
 * contains the following values:
 *
 * WARN_MS|<default number of miliseconds needed to generate a warning>|
 * CRIT_MS|<default number of miliseconds needed to generate a critical>|
 *
 * $Log: check_port.c,v $
 * Revision 1.1  1999/05/17 14:25:31  netsaint
 * Initial revision
 *
 *
*/

#include "/usr/local/src/netsaint/include/plugins.h"

int main(int argc, char *argv[])
{
  char command_name[MAX_CHARS];
  char config_file_net[MAX_CHARS];
  char ip_address[MAX_CHARS];
  char ms_crit[MAX_CHARS];
  char ms_warn[MAX_CHARS];
  char port_net[MAX_CHARS];
  char protocol[MAX_CHARS];
  char system_name[MAX_CHARS];

  int crit_ms;
  int end_time;
  int net_port;
  int get_defaults;
  int micro_seconds;
  int result;
  int return_value;
  int seconds;
  int socket_name;
  int start_time;
  int total_time;
  int warn_ms;

  struct timeval end_buff;
  struct timeval start_buff;
  struct timezone end_tz;
  struct timezone start_tz;

  /* Initialize alarm signal handling */

  signal(SIGALRM,alarm_signal);

  strcpy(command_name,get_command_name(argv[0]));
  if(!((argc==5) || (argc==7)))
  {
    printf("\n");
    printf(" Incorrect number of arguments supplied\n");
    printf("\n");
    printf(" PORT socket plugin for NetSaint\n");
    printf(" Copyright (c) 1999 Adam G. Bowen (agbowen@bealenet.com)\n");
    printf(" $Revision: 1.1 $\n");
    printf(" Last Modified $Date: 1999/05/17 14:25:31 $\n");
    printf(" License: GPL\n");
    printf("\n");
    printf(" Description:\n");
    printf("\n");
    printf(" This plugin will establish a socket on the port number passed on the command\n");
    printf(" line to the host specified by ipaddress.   If any error occures while\n");
    printf(" creating the socket, or closing the socket, this error will result in an\n");
    printf(" alert.  The incorrect responce or responce time above the threshold vaules\n");
    printf(" will also cause an alert. \n");
    printf("\n");
    printf(" Usage: %s ipaddress sys_type prot_number protocol\n",command_name);
    printf(" Usage: %s ipaddress sys_type prot_number protocol <warn_ms> <crit_ms>\n",command_name);
    printf("\n");
    printf(" Required input:\n");
    printf("\n");
    printf(" ipaddress = The ipaddress of the remote system to run the check on.\n");
    printf(" sys_type = The remote system type.\n");
    printf(" port_number = The port to connect to on the remote system.\n");
    printf(" protocol = The protocol to use for the socket connection.\n");
    printf("\n");
    printf(" Optional input:\n");
    printf("\n");
    printf(" <warn_ms> = Number of miliseconds necessary to result in a WARNING state.\n");
    printf(" <crit_ms> = Number of miliseconds necessary to result in a CRITICAL state.\n");
    printf("\n");
    printf(" If <warn_ms> and <crit_ms> are not passed on the command line, they will be\n");
    printf(" set to the default values in the %s config file.\n", command_name);
    printf("\n");
    printf(" sys_type is used to determine which config file to use to generate the\n");
    printf(" remote command.\n");
    printf("\n");
    return_value = STATE_UNKNOWN;
  }
  else
  {
    /* Set up config files and get the command line information */

    strcpy(ip_address,argv[1]);
    strcpy(system_name,argv[2]);
    strcpy(port_net,argv[3]);
    strcpy(protocol,argv[4]);

    strcpy(config_file_net,CONFIG_DIR);
    strcat(config_file_net,command_name);
    strcat(config_file_net,"/");
    strcat(config_file_net,system_name);

    if(argc == 5)
    {
      get_defaults = TRUE;
    }
    else
    {
      get_defaults = FALSE;
      strcpy(ms_warn,argv[5]);
      strcpy(ms_crit,argv[6]);
    }

    /* Check if config files exist */

    if (access(config_file_net, EXISTS) != 0 )
    {
      printf("Config file %s does not exist!\n",config_file_net);
      return_value = STATE_UNKNOWN;
    }
    else
    {

      /* Network config file variables */

      if((get_defaults == TRUE) && ((return_value=get_var("WARN_MS", config_file_net, ms_warn)) != STATE_OK))
      {
        printf("WARN_MS entry not found in config file %s!\n",config_file_net);
      }
      else if((get_defaults == TRUE) && ((return_value=get_var("CRIT_MS", config_file_net, ms_crit)) != STATE_OK))
      {
        printf("CRIT_MS entry not found in config file %s!\n",config_file_net);
      }
      else
      {

        /* Check alert level consistency */

        warn_ms=atoi(ms_warn);
        crit_ms=atoi(ms_crit);
        return_value = check_consistency(warn_ms, crit_ms);
        if(return_value == STATE_OK)
        {

          /* Check the network */

          net_port=atoi(port_net);
          gettimeofday(&start_buff, &start_tz);

          /* Set alarm */

          alarm(TIME_OUT); 
          if((result=open_socket(&socket_name, ip_address, net_port, protocol)) != STATE_OK)
          {
            return_value=exit_error(result,ip_address,protocol,net_port);
          }
          else if((result=close_socket(&socket_name)) != STATE_OK)
          {
            return_value=exit_error(result,ip_address,protocol,net_port);
          }
          else
          {

            /* Nothing hungup so reset alarm */

            alarm(0); 
            gettimeofday(&end_buff, &end_tz);
            seconds=(start_buff.tv_sec%1000);
            micro_seconds=start_buff.tv_usec;
            start_time=((seconds * 1000) + (micro_seconds/1000));
            seconds=(end_buff.tv_sec%1000);
            micro_seconds=end_buff.tv_usec;
            end_time=((seconds * 1000) + (micro_seconds/1000));
            total_time = end_time - start_time;
            if(total_time > crit_ms)
            {
              return_value = STATE_CRITICAL;
            }
            else if(total_time > warn_ms)
            {
              return_value = STATE_WARNING;
            }
            if(return_value == STATE_OK)
            {
              printf("PORT %d on host %s ok - %d ms responce time.\n",net_port, ip_address, total_time);
            }
            else
            {
              printf("PORT %d on host %s error slow responce time - %d ms responce time.\n",net_port, ip_address, total_time);
            }
          }
        }
      }
    }
  }
  return return_value;
}
