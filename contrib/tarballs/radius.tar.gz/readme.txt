You must have the radiusclient source code in order to build a radius plugin
with this code.  Use the radexample.c file included with this archive instead
of the one supplied with radiusclient when compiling...

You can grab the radiusclient source code from:

http://www.mcs-hh.de/~lf/radius/radius.html


-----

From nick.shore@multithread.co.uk Wed Oct  6 11:17:47 1999
Date: Wed, 6 Oct 1999 15:41:35 +0100
From: Nick Shore <nick.shore@multithread.co.uk>
To: "Netsaint@Linuxbox. Com" <netsaint@linuxbox.com>
Subject: RADIUS plugin


Ethan,

Here's a RADIUS plugin which uses the radiusclient library which you had a
link to on your web site.

I've just changed the radexample to be netsaint friendly.

Just build this radexample instead of the one supplied with radiusclient
then set up a radiusclient.conf file (there's an example in the
distribution)
for each radius you want to test ( we've got 3)

usage:

radexample username password configfile [checklogin]

if you specify checklogin then it raises a critical if the login
is not successful, otherwise critical is only raised on a timeout.

I hope this will be useful.

Nick.

